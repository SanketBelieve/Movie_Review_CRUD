from django.shortcuts import render,redirect

# Create your views here.
from .forms import MoviereviewForm 
from .models import Moviereview 

def addview(request):
    form=MoviereviewForm()
    if request.method=='POST':
        form=MoviereviewForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/a1/show/')
    return render(request,'app1/add.html',{'form':form})    

def updateview(request,pk):
    obj=Moviereview.objects.get(id=pk)
    if request.method=='POST':
        form=MoviereviewForm(request.POST,instance=obj)
        if form.is_valid():
            form.save()
            return redirect('/a1/show/')
    return render(request,'app1/add.html',{'form':form}) 

def showview(request):
    query=Moviereview.objects.all()
    return render(request,'app1/show.html',{'objects':query})

def deleteview(request,x):
    obj=Moviereview.objects.get(id=x)
    if request.method=="POST":
        obj.delete()
        return redirect('/a1/show/')
    return render(request,"app1/delete.html",{"obj":obj})
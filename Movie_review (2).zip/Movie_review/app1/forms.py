from django import forms 
from .models import Moviereview

class MoviereviewForm(forms.ModelForm):
    class Meta:
        model=Moviereview
        fields='__all__'
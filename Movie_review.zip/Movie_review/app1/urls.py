from django.urls import path 
from .views import * 

urlpatterns=[
    path('add/',addview),
    path('show/',showview),
    path('update/<int:pk>/',updateview),
    path('delete/<int:x>/',deleteview)
]
from django.db import models

statuss=[('published','Published'),('not published','Not Published')]
genere=[('horror','Horror'),('action','Action'),('sci-fi','Sci-fi'),('comedy','Comedy'),('thriller','Thriller')]
# Create your models here.
class Moviereview(models.Model):
    id=models.IntegerField(primary_key=True)
    movie_title=models.CharField(max_length=100)
    director=models.CharField(max_length=100)
    review_content=models.CharField(max_length=100)
    rating=models.IntegerField()
    created_at=models.DateField()
    reviewer_email_id=models.CharField(max_length=50,unique=True)
    status=models.CharField(max_length=20,choices=statuss)
    generes=models.CharField(max_length=20,choices=genere)
    
    
    
    